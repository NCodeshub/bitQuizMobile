<?php

$a = "string";
echo "test"[1];
?>